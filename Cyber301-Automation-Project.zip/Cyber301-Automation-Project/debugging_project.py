"""Number guessing game with logging and input validation.

Based on debugging techniques in Automate the Boring Stuff with Python.
"""

import logging
import random

# Save debugging information to a file instead of filling the game screen.
logging.basicConfig(
    filename="debug_log.txt",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filemode="w",
)


def play_game(secret_number=None, input_func=input, print_func=print):
    """Play the game; optional arguments make the code easier to test."""
    # Choose the secret number unless a test provides one.
    if secret_number is None:
        secret_number = random.randint(1, 20)
    if not 1 <= secret_number <= 20:
        raise ValueError("Secret number must be between 1 and 20.")

    logging.debug("Game started; secret number is %s", secret_number)
    print_func("I am thinking of a number between 1 and 20.")

    # Give the player six chances to guess the number.
    for attempt in range(1, 7):
        while True:
            try:
                guess = int(input_func(f"Guess {attempt}/6: "))
                if not 1 <= guess <= 20:
                    print_func("Please enter a number from 1 to 20.")
                    logging.warning("Guess outside allowed range: %s", guess)
                    continue
                break
            except ValueError:
                print_func("Please enter a whole number.")
                logging.warning("Player entered something that was not an integer")

        # Log each guess so the game can be checked later.
        logging.debug("Attempt %s: player guessed %s", attempt, guess)
        if guess < secret_number:
            print_func("Too low!")
        elif guess > secret_number:
            print_func("Too high!")
        else:
            print_func(f"Correct! You guessed it in {attempt} tries.")
            logging.info("Player won in %s tries", attempt)
            return True

    print_func(f"Out of guesses! The number was {secret_number}.")
    logging.info("Player lost after six guesses")
    return False


if __name__ == "__main__":
    play_game()
