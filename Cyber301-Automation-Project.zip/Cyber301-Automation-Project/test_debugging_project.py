"""Basic tests for the guessing game."""
import unittest
from debugging_project import play_game


class GuessingGameTests(unittest.TestCase):
    def run_with_answers(self, answers, secret):
        entries = iter(answers)
        output = []
        result = play_game(secret, lambda prompt: next(entries), output.append)
        return result, output

    def test_correct_guess(self):
        result, output = self.run_with_answers(["5", "15", "10"], 10)
        self.assertTrue(result)
        self.assertIn("Correct! You guessed it in 3 tries.", output)

    def test_invalid_input_does_not_use_turn(self):
        result, output = self.run_with_answers(["hello", "25", "10"], 10)
        self.assertTrue(result)
        self.assertIn("Correct! You guessed it in 1 tries.", output)

    def test_six_wrong_guesses(self):
        result, output = self.run_with_answers(["1"] * 6, 10)
        self.assertFalse(result)
        self.assertIn("Out of guesses! The number was 10.", output)


if __name__ == "__main__":
    unittest.main()
