# CYBER 301 Automation Project: Debugging a Python Guessing Game

## Project Selected
I chose the **Debugging** topic from *Automate the Boring Stuff with Python* by Al Sweigart. I used the book's ideas about logging and checking code to build a number guessing game that records useful debugging information.

Book: https://automatetheboringstuff.com/

## What the Script Does
The computer picks a random number between 1 and 20. The player has six chances to guess the number. The program tells the player if each guess is too high or too low. It also checks for incorrect input, such as letters or numbers outside the range.

The script creates a file called `debug_log.txt` to record guesses, warnings, and the game's result. This file helps me see what happened if the program has a problem.

## How to Run It
1. Install Python 3 if needed.
2. Download `debugging_project.py` from this repository.
3. Open a terminal in the folder containing the file.
4. Run `python debugging_project.py` (or `python3 debugging_project.py` on some computers).
5. Enter your guesses when asked.
6. Open `debug_log.txt` after playing to see the debugging information.

No extra packages are required.

## Sample Input and Output
```text
I am thinking of a number between 1 and 20.
Guess 1/6: 5
Too low!
Guess 2/6: 15
Too high!
Guess 3/6: 10
Correct! You guessed it in 3 tries.
```
This example assumes the secret number is 10. Your game will normally choose a random number.

## Challenges Encountered
One challenge was making sure the game did not crash when someone typed letters instead of a number. I used `try` and `except` to handle this problem. I also made sure guesses outside 1 to 20 did not use up a turn.

## Improvements and Modifications
I added a debugging log file, input checks, and clear messages for the player. I also put the game inside a function so it is easier to test. The log file is recreated each time the program starts.

## Files
- `debugging_project.py` — the Python game
- `README.md` — project instructions and explanation
- `test_debugging_project.py` — simple automated tests

## Testing
Run `python -m unittest test_debugging_project.py` to check that the game handles correct guesses, invalid input, and running out of guesses.
